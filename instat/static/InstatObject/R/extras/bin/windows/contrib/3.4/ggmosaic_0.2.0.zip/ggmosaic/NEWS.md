# ggmosaic 0.2.0


## Small Usage Changes

- fixed bugs in previous versions
