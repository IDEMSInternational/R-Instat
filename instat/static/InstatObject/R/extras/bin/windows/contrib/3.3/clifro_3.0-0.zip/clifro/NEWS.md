clifro 3.0 (10-August-2016)
==========

### Minor Improvements
* Allow expressions in legend title for windrose

### Major Bug Fixes
* HTTPS required due to a recent change in NIWA's proxy server -- Fixed Issue #3.
  As a result older versions of `clifro` don't seem to work on Windows due to an
  SSL certificate problem.

### Minor Bug Fixes
* `cf_find_station` correctly gives distances instead of longitudes

clifro 2.4-1 (15-January-2016)
==============================

### New Features
* CRAN release

### Minor Improvements
* Update citation information

clifro 2.4-0 (05-March-2015)
============================

### Minor Improvements
* CRAN release

### Bug Fixes
* Bug fixed for subsetting _cfStation_ using `[`

clifro 2.2.3 (04-March-2015)
============================

* Start using NEWS to document changes to _clifro_
