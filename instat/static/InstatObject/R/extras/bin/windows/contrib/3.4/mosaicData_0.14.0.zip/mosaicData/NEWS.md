# mosaicData package NEWS

## mosaic 0.14

 * added Births data set
 * added GoosePermits data set
 