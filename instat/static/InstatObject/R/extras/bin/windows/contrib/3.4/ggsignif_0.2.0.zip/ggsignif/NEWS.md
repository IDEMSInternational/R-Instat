


# Version 0.2.0

- Fixed bug, when `alpha()` from another package was loaded (issue #2)
- Added additional parameters to customize bracket linetype, textsize, size (issue #5)
- Fixed bug when annotation was identical for different brackets (issue #6)
- Fixed bug when multiple comparisons referenced the same block (issue #8)


# Initial Release (0.1.0)

The package has been made publicly available on CRAN: https://CRAN.R-project.org/package=ggsignif
