# insight 0.1.2

## General

* Initial release.