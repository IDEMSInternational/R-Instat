# This is file ../spam/demo/article-jss-example2.R
# This file is part of the spam package, 
#      http://www.math.uzh.ch/furrer/software/spam/
# by Reinhard Furrer [aut, cre], Florian Gerber [ctb]
     


# This demo is depreciated. Please run
demo('jss15-BYM')

