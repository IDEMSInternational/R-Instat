# 1.0.2
- `with_makevars()` gains an `assignment` argument to allow specifying
  additional assignment types.

# 1.0.1
- Relaxed R version requirement to 3.0.2 (#35, #39).
- New `with_output_sink()` and `with_message_sink()` (#24).

# 1.0.0

First Public Release
