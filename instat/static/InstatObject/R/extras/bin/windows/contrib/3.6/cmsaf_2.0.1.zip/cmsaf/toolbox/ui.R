# the CM SAF R Toolbox.
#
# You should not use this R-script on its own!
#
# Have fun with the CM SAF R TOOLBOX!
#                                              (Steffen Kothe / CM SAF 2019-08-08)
#__________________________________________________________________________________

descriptionString <-
  "

The CM SAF R TOOLBOX 2.0.1 -- 'Don`t Panic'

The intention of the CM SAF R Toolbox is to help you using
CM SAF NetCDF formatted data

This includes:
  1. Preparation of ordered CM SAF data files.
  2. Analysis of prepared CM SAF data.
  3. Visualization of the results.

To begin, choose a .tar file in the prepare section or jump
right in and analyze or visualize a .nc file.

Suggestions for improvements and praise for the developers
can be sent to contact.cmsaf@dwd.de.

- Steffen Kothe - 2019-08-08 -"

# Variable can be found in global.R
if (isRunningLocally) {
  analyzeString <-
    "<h2>Analyze</h2>
  <p>Please select a NetCDF file <strong>(.nc)</strong> to start the analysis process.</p>
  <p>This is the second step after you prepared your data.<p/>
  <p>The input for this application has to be a NetCDF file</p>
  <p>(usually the output of step one (Prepare)).</p>
  <br>
  <p>This application will help you to analyze and manipulate your data.</p>
  <p>The output is usually written in a NetCDF file in the according output folder.</p>"
} else {
  analyzeString <-
    "<h2>Analyze</h2>
  <p>Please select a NetCDF file <strong>(.nc)</strong> to start the analysis process.</p>
  <p>This is the second step after you prepared your data.<p/>
  <p>The input for this application has to be a NetCDF file</p>
  <p>(usually the output of step one (Prepare)).</p>
  <br>
  <p>This application will help you to analyze and manipulate your data.</p>
  <p>Again, make sure to download your session files before closing the application.</p>"
}

visualizeString <-
  "<h2>Visualize</h2>
<p>Please select a NetCDF file <strong>(.nc)</strong> to start the visualization.</p>
<br>
<p>This application can be used to display NetCDF data.</p>
<p>In addition, it provides information on the data and the NetCDF file.</p>"

# render string for colorspace
renderString <-
  '{
    option: function(item, escape) {
        // custom code to generate HTML before each option
        var tmp = item.value
        var imgname = tmp.toLowerCase().split(" ").join("_");
        imgname = "images/pal_"+imgname+".png";
        return( "<img class=\'select-pal\' src=\'"+imgname+"\'></img>" )
    }
}'

fluidPage(
  theme = shinythemes::shinytheme("flatly"),
  tags$head(tags$link(rel = "stylesheet", type = "text/css", href = "style.css")),
  tags$script(HTML(
    "var actionValue = 0;",
    "$(document).on('click', '.homeimg', function() {",
    "  actionValue = actionValue + 1;",
    "  Shiny.setInputValue('homeimg', actionValue);",
    "});"
  )),
  shinyjs::useShinyjs(),
  #### Setup Page ####
  tags$div(
    id = "setupPage",
    sidebarLayout(
      sidebarPanel(img(src = "R_Toolbox_Logo.png", class = "homeimg", width = "100%;", style = "cursor: pointer; padding: 10px;"),
                   actionButton("prepare", label = "Prepare", class = "btn btn-primary btn-lg btn-block",
                                style = "font-size: 30px"),
                   actionButton("analyze", label = "Analyze", class = "btn btn-primary btn-lg btn-block",
                                style = "font-size: 30px"),
                   actionButton("visualize", label = "Visualize", class = "btn btn-primary btn-lg btn-block",
                                style = "font-size: 30px"),
                   actionButton("exit", label = "EXIT", class = "btn btn-danger btn-lg btn-block",
                                style = "font-size: 30px"),
                   shinyjs::hidden(tags$div(id = "downloader",
                                            downloadButton("download",
                                                           "Download the session files."))),
                   shinyjs::hidden(actionButton("modify_userDir",
                                                "View or edit the user directory."))),

      # Description panel.
      mainPanel(tags$div(id = "panel_home",
                         tags$pre(descriptionString)),
                tags$div(id = "panel_content",
                         #### Preparation Stuff ####
                         shinyjs::hidden(
                           tags$div(id = "panel_prepareGo",
                                    uiOutput("prepareString"),
                                    br(),
                                    shinyjs::hidden(actionButton("tarFileLocal",
                                                                 label = "Browse files...")),
                                    shinyjs::hidden(fileInput(inputId = "tarFileRemote",
                                                              label = "Browse files...",
                                                              multiple = FALSE,
                                                              accept = c("application/x-tar", ".tar"))))),
                         shinyjs::hidden(
                           tags$div(id = "panel_prepareInput1",
                                    uiOutput("dateRange_ui"),
                                    shinyjs::disabled(actionButton("untarAndUnzip",
                                                                   "Untar and unzip files.")))),
                         # Panel after untaring and unzipping.
                         # First a few spinner classes.
                         shinyjs::hidden(tags$div(id = "spinner_prepare1",
                                                  class = "spinner",
                                                  tags$div(class = "spinner-title", h4("Extracting date range...")),
                                                  tags$div(class = "double-bounce1"),
                                                  tags$div(class = "double-bounce2"))),
                         shinyjs::hidden(tags$div(id = "spinner_prepare2",
                                                  class = "spinner",
                                                  tags$div(class = "spinner-title", h4("Untaring files...")),
                                                  tags$div(class = "double-bounce1"),
                                                  tags$div(class = "double-bounce2"))),
                         shinyjs::hidden(tags$div(id = "spinner_prepare3",
                                                  class = "spinner",
                                                  tags$div(class = "spinner-title", h4("Creating your output file...")),
                                                  tags$div(class = "double-bounce1"),
                                                  tags$div(class = "double-bounce2"))),
                         shinyjs::hidden(selectInput(inputId = "aux_select",
                                                     label = "File does not contain lon/lat information. Please provide an auxiliary file.",
                                                     choices = c("Choose an option" = "",
                                                                 "Provide local file" = "local",
                                                                 "Download file" = "download",
                                                                 "Cancel" = "cancel"))),

                         # Then the actual classes.
                         shinyjs::hidden(
                           tags$div(id = "panel_prepareInput2",
                                    fluidRow(column(5,
                                                    uiOutput("variable_ui"),
                                                    uiOutput("lonRange_ui"),
                                                    uiOutput("latRange_ui"),
                                                    shinyjs::hidden(uiOutput("level_ui")),
                                                    selectInput("outputFormat",
                                                                "Select output format",
                                                                choices = c("NetCDF4" = 4, "NetCDF3" = 3),
                                                                selected = "NetCDF4"),
                                                    checkboxInput("deleteExtracted",
                                                                  "Delete the extracted files after the output has been created? (Recommended)",
                                                                  value = TRUE),
                                                    actionButton("createOutput",
                                                                 "Create output file!")),
                                             column(7,
                                                    plotOutput("previewSpatialCoveragePlot"))))),

                         #### Analyze Stuff ####
                         shinyjs::hidden(
                           tags$div(id = "panel_analyzeGo",
                                    HTML(analyzeString),
                                    shinyjs::hidden(uiOutput("ncFile_analyze")),
                                    tags$div(id = "ncFileWrapper",
                                             shinyjs::hidden(actionButton("useOutputFile_analyze",
                                                                          label = "Analyze this file!")),
                                             shinyjs::hidden(h5(id = "or_analyze", "or")),
                                             shinyjs::hidden(actionButton("ncFileLocal_analyze",
                                                                          label = "Choose a file...")),
                                             shinyjs::hidden(fileInput(inputId = "ncFileRemote_analyze",
                                                                       label = "Choose a file...",
                                                                       multiple = FALSE,
                                                                       accept = c(".nc")))))),
                         shinyjs::hidden(
                           tags$div(id = "panel_analyze",
                                    fluidRow(
                                      column(width = 5,
                                             uiOutput("usedVariable"),
                                             # Operator groups and operators can be found in global.R
                                             selectInput("operatorGroup",
                                                         label = "Select a group of operators",
                                                         choices = operatorGroups,
                                                         width = "320px"),
                                             uiOutput("operator"),
                                             # Operator options
                                             shinyjs::hidden(numericInput("constant",
                                                                          "Enter a number",
                                                                          value = 1,
                                                                          width = "320px")),
                                             shinyjs::hidden(uiOutput("region_to_select")),
                                             shinyjs::hidden(tags$div(id = "point",
                                                                      numericInput("latPoint",
                                                                                   "Select latitude point",
                                                                                   value = 0),
                                                                      numericInput("lonPoint",
                                                                                   "Select longitude point",
                                                                                   value = 0))),
                                             shinyjs::hidden(uiOutput("dateRange_to_select")),
                                             shinyjs::hidden(checkboxInput("useFastTrend",
                                                                           "Do you want to use fast computation (memory consuming)",
                                                                           value = TRUE)),
                                             shinyjs::hidden(numericInput("percentile",
                                                                          "Please enter a percentile number",
                                                                          value = 0.95,
                                                                          min = 0,
                                                                          max = 1,
                                                                          step = 0.05,
                                                                          width = "320px")),
                                             shinyjs::hidden(checkboxGroupInput("months",
                                                                                "Please select months",
                                                                                c("January", "February", "March", "April", "May", "June",
                                                                                  "July", "August", "September", "October", "November", "December"),
                                                                                width = "320px")),
                                             shinyjs::hidden(uiOutput("years_to_select")),
                                             shinyjs::hidden(checkboxGroupInput("times",
                                                                                "Please select time points",
                                                                                c("00:00:00","00:01:00","00:02:00","00:03:00","00:04:00","00:05:00",
                                                                                  "00:06:00","00:07:00","00:08:00","00:09:00","00:10:00","00:11:00",
                                                                                  "00:12:00","00:13:00","00:14:00","00:15:00","00:16:00","00:17:00",
                                                                                  "00:18:00","00:19:00","00:20:00","00:21:00","00:22:00","00:23:00"),
                                                                                width = "320px")),
                                             shinyjs::hidden(selectInput("method",
                                                                         "Select regridding method",
                                                                         choices = c("Nearest Neighbour interpolation" = "nearest",
                                                                                     "Bilinear Interpolation" = "bilinear",
                                                                                     "Conservative remapping" = "conservative"),
                                                                         width = "320px")),
                                             selectInput("format",
                                                         "Select output format",
                                                         choices = c("NetCDF4" = 4, "NetCDF3" = 3),
                                                         width = "320px"),
                                             checkboxInput("applyAnother",
                                                           "Do you want to apply another operator afterwards?"),
                                             checkboxInput("instantlyVisualize",
                                                           "Do you want to visualize the results right away?",
                                                           value = TRUE),
                                             h5("Hint: You can start with a new input file by clicking on 'Analyze'."),
                                             actionButton("applyOperator",
                                                          label = "Apply operator",
                                                          class = "btn btn-success btn-lg btn-block",
                                                          style = "font-size: 30px"),
                                             h5("If you would like to have more functions included contact:"),
                                             h5("cmsaf.training@dwd.de"),
                                             br()
                                      ),
                                      column(width = 7,
                                             tags$div(id = "nc_info",
                                                      h3("Short File Information"),
                                                      verbatimTextOutput("ncShortInfo")),
                                             shinyjs::hidden(tags$div(id = "listOfOperators",
                                                                      h3("List of applied operators"),
                                                                      tableOutput("appliedOperators"))),
                                             tags$div(id = "wrapper_analyze_spinner",
                                                      shinyjs::hidden(tags$div(id = "spinner_analyze",
                                                                               class = "spinner",
                                                                               tags$div(class = "spinner-title", h4("Applying the given operation...")),
                                                                               tags$div(class = "double-bounce1"),
                                                                               tags$div(class = "double-bounce2")))))))),

                         #### Visualize Stuff ####
                         shinyjs::hidden(
                           tags$div(id = "panel_visualizeGo",
                                    HTML(visualizeString),
                                    shinyjs::hidden(uiOutput("ncFile_visualize")),
                                    tags$div(id = "ncFileWrapper",
                                             shinyjs::hidden(actionButton("useOutputFile_visualize",
                                                                          label = "Visualize this file!")),
                                             shinyjs::hidden(h5(id = "or_visualize", "or")),
                                             shinyjs::hidden(actionButton("ncFileLocal_visualize",
                                                                          label = "Choose a file...")),
                                             shinyjs::hidden(fileInput(inputId = "ncFileRemote_visualize",
                                                                       label = "Choose a file...",
                                                                       multiple = FALSE,
                                                                       accept = c(".nc"))))),
                           shinyjs::hidden(tags$div(id = "spinner_visualize",
                                                    class = "spinner",
                                                    tags$div(class = "spinner-title", h4("Preparing your plot...")),
                                                    tags$div(class = "double-bounce1"),
                                                    tags$div(class = "double-bounce2")))))))),

  #### VISUALIZE PAGE ####
  shinyjs::hidden(tags$div(
    id = "visualizePage",

    sidebarLayout(
      sidebarPanel(img(src = "R_Toolbox_Logo.png", width = "100%;", style = "padding: 10px;"),
                   h3("Visualizer Options:"),
                   tags$div(id = "sidebar_2d_plot",
                            uiOutput("timestep_visualize"),
                            conditionalPanel(condition = "input.proj == 'rect'",
                                             checkboxInput("show_zoom", "Show Zoom"),
                                             checkboxInput("plot_region", "Plot region"),
                                             conditionalPanel(condition = "input.plot_region",
                                                              # All countries can be found in global.R
                                                              fluidRow(column(6, uiOutput("division_options")),
                                                                       column(6, uiOutput("region_options"))),
                                                              shinyjs::hidden(actionButton("shapefileLocal",
                                                                                           label = "Choose a shape file...")),
                                                              shinyjs::hidden(fileInput(inputId = "shapefileRemote",
                                                                                        label = "Choose a shape file...",
                                                                                        multiple = FALSE,
                                                                                        accept = c(".shp")))),
                                             conditionalPanel(condition = "input.plot_region",
                                                              br()),
                                             conditionalPanel(condition = "!input.plot_region",
                                                              uiOutput("lon_visualize"),
                                                              uiOutput("lat_visualize"))),
                            conditionalPanel(condition = "input.proj == 'ortho'",
                                             fluidRow(column(4,
                                                             numericInput("yort",
                                                                          label = "Center Lon",
                                                                          value = 0,
                                                                          step = 5,
                                                                          min = -175,
                                                                          max = 175)),
                                                      column(4,
                                                             numericInput("xort",
                                                                          label = "Center Lat",
                                                                          value = 0,
                                                                          step = 5,
                                                                          min = -85,
                                                                          max = 85)),
                                                      column(4,
                                                             numericInput("rort",
                                                                          label = "Rotation",
                                                                          value = 0,
                                                                          step = 5,
                                                                          min = -90,
                                                                          max = 90)))),
                            fluidRow(column(6,
                                            numericInput("num_brk",
                                                         label = "Number of Colors",
                                                         value = 32,
                                                         min = 2,
                                                         max = 64,
                                                         step = 1)),
                                    column(6,
                                            conditionalPanel(condition = "input.proj == 'rect' && !input.plot_region",
                                             numericInput("num_tick",
                                                          label = "Number of Ticks",
                                                          value = 5,
                                                          min = 2,
                                                          max = 64,
                                                          step = 1)))),
                                             selectizeInput("PAL", label = "Colorbar",
                                                            choices = list(),
                                                            options = list(create = TRUE,
                                                                           render = I(renderString))),
                                             checkboxInput("reverse", "Reverse", value = FALSE, width = NULL),
                            conditionalPanel(condition = "input.proj == 'rect' || input.plot_region",
                                             fluidRow(column(6,
                                                             uiOutput("num_rmin")),
                                                      column(6,
                                                             uiOutput("num_rmax")))),
                            conditionalPanel(condition = "!input.plot_region",
                                             checkboxInput("int","Plot Country Borders"),
                                             checkboxInput("plot_rinstat","Plot R-Instat"),
                                             shinyjs::hidden(actionButton("instat_file_local",
                                                                          label = "Browse files...")),


                                             shinyjs::hidden(fileInput(inputId = "instat_file_remote",
                                                                       label = "Browse files...",
                                                                       multiple = FALSE,
                                                                       accept = c(".RData")))),
                            conditionalPanel(condition = "input.plot_region || input.proj == 'rect'",
                                             checkboxInput("location", "Plot Own Location"),
                                             conditionalPanel(condition = "input.location == true",
                                                              tags$div(id = "ownLocation",
                                                                       fluidRow(column(6,
                                                                                       numericInput("lon_loc",
                                                                                                    label = "Lon",
                                                                                                    value = 8.75,
                                                                                                    min = -180,
                                                                                                    max = 180)),
                                                                                column(6,
                                                                                       numericInput("lat_loc",
                                                                                                    label = "Lat",
                                                                                                    value = 50.11,
                                                                                                    min = -90,
                                                                                                    max = 90)),
                                                                                column(6,
                                                                                       textInput("name_loc",
                                                                                                 label = "Name",
                                                                                                 value = "Offenbach")),
                                                                                column(6,
                                                                                       tags$label(" "),
                                                                                       actionButton("add_loc", label = "Add now", width = "100%")))))),
                            conditionalPanel(condition = "!input.plot_region",
                                             selectInput("proj",
                                                         label = "Projection",
                                                         choices = c(Rectangular = "rect", Orthographic = "ortho"))),
                            uiOutput("title_text"),
                            uiOutput("subtitle_text"),
                            uiOutput("scale_caption")),
                   # FOR NOW NOT ALLOWING CHANGES TO WIDTH AND HEIGHT IN APP. (DO IT IN GLOBAL.R)
                   # uiOutput("width_height"),

                   tags$div(id = "sidebar_1d_plot",
                            uiOutput("x_visualize"),
                            uiOutput("y_visualize"),
                            colourpicker::colourInput("integer",
                                                      "Color",
                                                      showColour = "background",
                                                      palette = "limited",
                                                      returnName = TRUE,
                                                      value = "royalblue4"),
                            selectInput("checkGroup_type",
                                        label = "Line Type",
                                        choices = list("Line" = 1,
                                                       "Points" = 2,
                                                       "Line+Points" = 3,
                                                       "Steps" = 4,
                                                       "Histogram" = 5),
                                        selected = 1),
                            checkboxInput("trend","Add linear trend line"),
                            checkboxInput("analyze_timeseries","Analyze timeseries"),
                            numericInput("ticknumber",
                                         label = "Number of major ticks",
                                         value = 6,
                                         min = 2),
                            selectInput("dateformat",
                                        label = "Date format",
                                        choices = list("YYYY" = 1,
                                                       "YYYY-MM" = 2,
                                                       "YYYY-MM-DD" = 3),
                                        selected = 2),
                            uiOutput("title_text_1d"),
                            uiOutput("subtitle_text_1d")),

                   # FOR NOW NOT ALLOWING CHANGES TO WIDTH AND HEIGHT IN APP. (DO IT IN GLOBAL.R)
                   # uiOutput("width_height"),
                   fluidRow(column(8,
                                   downloadButton("downloadPlot",
                                                  "Save plot",
                                                  style = "width: 100%;")),
                            column(4,
                                   actionButton("backToSetup",
                                                label = "Back",
                                                class = "exit-button",
                                                width = "100%")))),

      # Description panel.
      mainPanel(tabsetPanel(id = "mainVisualizeTabset",
                            tabPanel("Plot",
                                     tags$div(id = "plots_div",
                                              conditionalPanel(condition = "input.show_zoom",
                                                               plotOutput("previewSpatialCoveragePlot_vis",
                                                                          brush = brushOpts(id = "zoom_brush",
                                                                                            resetOnNew = TRUE))),
                                              tags$div(id = "myImage",
                                                       shinyjs::hidden(imageOutput("myImage_1d")),
                                                       shinyjs::hidden(imageOutput("myImage_2d"))),
                                              shinyjs::hidden(tags$div(id = "spinner_plot1",
                                                                       h3("Rendering plot..."))))),
                            tabPanel("Statistics",
                                     h4("Some numbers for the selected region."),
                                     verbatimTextOutput("statistics"),
                                     fluidRow(column(6,
                                                     imageOutput("myHist")),
                                              column(6,
                                                     imageOutput("myComp")))),
                            tabPanel("File Summary",
                                     fluidRow(column(12,
                                                     h4("Short File Info"),
                                                     verbatimTextOutput("summary1")),
                                              column(12,
                                                     h4("Detailed File Info"),
                                                     verbatimTextOutput("summary2")))),
                            tabPanel("About",
                                     fluidRow(column(8,
                                                     h4("The CM SAF Visualizer"),
                                                     verbatimTextOutput("about")),
                                              column(8,
                                                     h4("Good to know"),
                                                     verbatimTextOutput("tipps")),
                                              column(6,
                                                     uiOutput("link")))))))))
)
