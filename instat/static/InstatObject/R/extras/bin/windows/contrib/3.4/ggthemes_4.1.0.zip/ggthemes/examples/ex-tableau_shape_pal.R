\dontrun{
  # need to set a font containing these values
  show_shapes(tableau_shape_pal()(5))
}
