### R code from vignette source 'Introduction.Rnw'
### Encoding: ASCII

###################################################
### code chunk number 1: preliminaries
###################################################
options(width=75)


