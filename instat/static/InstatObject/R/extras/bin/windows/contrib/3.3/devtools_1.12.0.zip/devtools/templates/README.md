# {{{ package }}}

The goal of {{{package}}} is to ...

{{#github}}
## Installation

You can install {{{ package }}} from github with:

```R
# install.packages("devtools")
devtools::install_github("{{{repo}}}/{{{username}}}")
```

{{/github}}
## Example

This is a basic example which shows you how to solve a common problem:

```R
...
```
