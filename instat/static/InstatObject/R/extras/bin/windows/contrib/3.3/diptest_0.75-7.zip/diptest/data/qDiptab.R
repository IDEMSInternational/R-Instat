qDiptab <- diptest:::rdRDS("extraData", "qDiptab.rds")
