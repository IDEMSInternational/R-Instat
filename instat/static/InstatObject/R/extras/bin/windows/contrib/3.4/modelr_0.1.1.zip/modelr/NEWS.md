# modelr 0.1.1

* Added a `NEWS.md` file to track changes to the package.

* Fixed R CMD CHECK note

* Updated usage of `reduce()` for upcoming purrr release

* More general `permute()` function
