## ---- echo = FALSE, results = "hide", message = FALSE--------------------
require("emmeans")
knitr::opts_chunk$set(collapse = TRUE, fig.width = 4.5)
options(show.signif.starts = FALSE)

## ----eval = FALSE--------------------------------------------------------
#  emmeans:::convert_workspace()

