# mosaicCore 0.2.0

* Some functions from `mosaic` and `ggformula` have been moved here to support a better dependency structure among the Project MOSAIC packages.  This package is unlikely to be needed in isolation, but functions from this package will be imported into the other packages as needed.  Some will also be re-exported.



